import logoChuva from './images/logoChuva.png';

const StudentLogin = () => {

    return (
        <>
            <nav class="navbar bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/home">
                        <img src={logoChuva} alt="Logo" width="30" height="24" class="d-inline-block align-text-top rounded"/>
                        <span className='text-white ms-2'>Chuva</span> <span className='text-primary'>Academy</span>
                    </a>
                </div>
            </nav>
        </>
    );

}


export default StudentLogin;