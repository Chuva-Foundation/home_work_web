
import axios from 'axios';
import { Navigate } from 'react-router-dom';

const SignUp = () => {
    const handleFormSubmitSignUp = async (e) => {
        e.preventDefault();
        try {
            const { userName, fullName, userType, email, password, confirmPassword, gender } = e.target;;
            const response = await axios.post('http://localhost:5000/user', {
                user_name: userName.value,
                full_name: fullName.value,
                email: email.value,
                password: password.value,
                confirm_password: confirmPassword.value,
                gender: gender.value,
                user_type: userType.value
            });
            console.log(response.data (Navigate ("./StudentLogin")));
        } catch( err) {
            console.log(err.message);
        }
    }

    return (
        <div className=''>
            <div className="modal-header border-bottom-0 pb-0 pt-0">
                <h3 class="modal-title justify-content-center">Create User</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body ">
                <form id='_he ' onSubmit={handleFormSubmitSignUp}>
                    <div className="form-floating mb-3">
                        <input id="userName" name='userName' className='form-control rounded-3' type='text' placeholder='User Name' required/>
                        <label for='userName'>User Name</label>
                    </div>
                    <div className="form-floating mb-3"> 
                        <input id="fullName" name="fullName" type="text" className='form-control rounded-3' placeholder='Full Name' required></input>
                        <label for="fullName" className='form-label'>Full name</label>
                    </div>
                    <div className="form-floating mb-3">
                        <input id='emailForm' name='email' className='form-control rounded-3' type="email" placeholder='example@gmail.com' required/>
                        <label for="emailForm" className='form-label'>Email</label>
                    </div>
                    <div className="form-floating mb-3">
                        <input id="passwordForm" name="password" className='form-control rounded-3' type="password" placeholder='********' required/>
                        <label for="passwordForm" className='form-label'>Password</label>
                    </div>
                    <div className="form-floating mb-3">
                        <input id='confirmPassword' name='confirmPassword' className='form-control rounded-3' type="password" placeholder='********' required/>
                        <label for="confirmPassword" className='form-label'>Confirm password</label>
                    </div>
                    <div className='my-2'>
                        <label className='label me-2'>Gender: </label>
                        <div className='form-check form-check-inline'>
                            <input id='male' name="gender" type="radio" className='form-check-input' value='male' checked/>
                            <label for="male" className='form-check-label'>male</label>
                        </div>
                        <div className='form-check form-check-inline'>
                            <input id="female" name="gender" type="radio" className='form-check-input' value='female'/>
                            <label for="female" className='form-check-label'>female</label>
                        </div>
                        <div className='form-check form-check-inline'>
                            <input id="other" name="gender" type="radio" className='form-check-input' value='other'/>
                            <label for="other" className='form-check-label'>other</label>
                        </div>
                    </div>
                    <label>User Type</label>
                    <div className='text-center mt-2'>
                        <div className='form-check form-check-inline'>
                            <input id='student' name="userType" type="radio" className='btn-check' autoComplete='off' value='student' checked/>
                            <label for="student" className='btn btn-outline-dark rounded-5'>Student</label>
                        </div>
                        <div className='form-check form-check-inline'>
                            <input id='teacher' name="userType" type="radio" className='btn-check' autoComplete='off' value='teacher' />
                            <label for="teacher" className='btn  btn-outline-dark rounded-5'>Teacher</label>
                        </div>
                    </div>
                    <div className='mt-3 text-center'>
                            <button className="btn w-100 btn-lg btn-primary" type="submit">Sign Up</button>
                    </div>
                </form>
            </div>
        </div>
    );
    };

export default SignUp;