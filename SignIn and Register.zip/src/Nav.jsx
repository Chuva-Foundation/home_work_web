import logoChuva from './images/logoChuva.png';
import { useState } from 'react';
import LogIn from './LogIn';
import SignUp from './SignUp';

const Nav = () => {

    const [ClickedBtn, setBtn] = useState('SignUp');

    const handleBtnClick = (event) => {
        setBtn(event.currentTarget.id);
    }
    
    const handleFormSubmit = (event) => {
        
    }

    

        
    return (
        <>
            <nav class="navbar bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/home">
                        <img src={logoChuva} alt="Logo" width="30" height="24" class="d-inline-block align-text-top rounded"/>
                        <span className='text-white ms-2'>Chuva</span> <span className='text-primary'>Academy</span>
                    </a>
                    <div>
                        <button id="LogIn" className='btn btn-outline-light me-2' data-bs-toggle="modal" data-bs-target="#Area" type='button' onClick={handleBtnClick}>log in</button>
                        <button id='SignUp' className='btn btn-warning me-2' data-bs-toggle="modal" data-bs-target="#Area" type='button' onClick={handleBtnClick}>sign up</button>
                        <div className='modal mt-2 ' id="Area" aria-labelledby="AreaLabel" aria-hidden="true">
                            <div className='modal-dialog'>
                                <div className='modal-content p-4 rounded-5'>
                                    {
                                        ClickedBtn === 'SignUp' ? <SignUp /> : <LogIn handleFormSubmit={handleFormSubmit}/>
                                    }
                                    <div className="modal-footer justify-content-center border-top-0 pt-0 pb-0">
                                        {
                                            ClickedBtn === 'SignUp' ? 
                                                <a id="LogIn" className='text-primary' style={{cursor: 'pointer', textDecoration: 'none'}} data-bs-toggle="modal" data-bs-target="#Area" type='button' onClick={handleBtnClick}>Already have an acount? Click here</a>
                                                : <a id="SignUp" className='text-primary' style={{cursor: 'pointer', textDecoration: 'none' }} data-bs-toggle="modal" data-bs-target="#Area" type='button' onClick={handleBtnClick}>Don't have an acount? Click here</a>
                                            
                                        }
                                    </div>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            </nav>
        </>
    );
}

export default Nav;