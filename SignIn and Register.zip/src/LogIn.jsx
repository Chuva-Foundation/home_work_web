import axios from "axios";
import validator from "validator";

const LogIn = () => {

    const handleFormSubmitLogIn = async (e) => {
        try {
            e.preventDefault();
            const {email, password } = e.target;

            if (validator.isEmail(email.value)) {
                const response = await axios.post('http://localhost:5000/log_in', {
                    email: email.value,
                    password: password.value
                })
                console.log(response.data.token);
            }
           else {
                alert('not a email');
           }
        
        } catch (err) {
            console.log(err.message);
        }
        
    }

    return (
        <div className="">
            <div className="modal-header border-bottom-0 pb-0 pt-1">
                <h3 class="modal-title">Log In</h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
                <form onSubmit={handleFormSubmitLogIn}>
                    
                    <div className="form-floating mb-4">
                        <input name="email" id='email' className='form-control rounded-3' type="email" placeholder='example@gmail.com'/>
                        <label for="email" >Email Adress</label>
                    </div>
                    <div className="form-floating">
                        <input name="password" id='formPassword' className='form-control rounded-3' type="password" placeholder='********'/>
                        <label for="formPassword" className='form-label'>Password</label>
                    </div>
                    
                    <div className='mt-4 text-center'>
                        <button className="btn btn-primary w-100 btn-lg" type="submit">log In</button>
                    </div>
                
                </form>
            </div>
        </div>
    );
};

export default LogIn;