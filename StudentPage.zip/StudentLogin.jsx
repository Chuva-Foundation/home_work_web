import logoChuva from './images/logoChuva.png';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import React, { useState } from 'react';
import {
    FaTh,
    FaBars,
    FaUserAlt,
    FaRegChartBar,
    FaCommentAlt,
    FaShoppingBag,
    FaThList
}from "react-icons/fa";
import { NavLink } from 'react-router-dom';


const StudentLogin = ({children}) => {
    
    const[isOpen ,setIsOpen] = useState(false);
    const toggle = () => setIsOpen (!isOpen);
    const menuItem=[
        {
            path:"/",
            name:"Dashboard",
            icon:<FaTh/>
        },
        {
            path:"/about",
            name:"About",
            icon:<FaUserAlt/>
        },
        {
            path:"/analytics",
            name:"Analytics",
            icon:<FaRegChartBar/>
        },
        {
            path:"/comment",
            name:"Comment",
            icon:<FaCommentAlt/>
        },
        {
            path:"/product",
            name:"Product",
            icon:<FaShoppingBag/>
        },
        {
            path:"/productList",
            name:"Product List",
            icon:<FaThList/>
        }
    ]

    return (
        <>
            <nav class="navbar bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/home">
                        <img src={logoChuva} alt="Logo" width="25" height="24" class="d-inline-block align-text-top rounded"/>
                        <span className='text-white ms-2'>Chuva</span> <span className='text-primary'>Academy</span>
                    </a>
                </div>
            </nav>
        </>
    );

}


export default StudentLogin;