import { createContext } from 'react';

export const GlobalAppContext = createContext(null);
