import React , { useContext } from 'react';
import { GlobalAppContext } from './../../context';
import logoChuva from '../../images/logoChuva.png';

function IndexContent() {

const { toggled , setToggled} = useContext(
    GlobalAppContext
);

// teste: lmbra kum tem q mete kel parte de tema (apesar kel t impossivel agr)

    return (
        <>
            <nav class="navbar bg-dark">
                <div class="container-fluid">
                    <a class="navbar-brand" href="/home">
                        <a href="#/" class="btn btn-outline-secondary mr-1" onClick={() =>setToggled(!toggled)}>Toggle Sidebar</a>
                        <img src={logoChuva} alt="Logo" width="25" height="24" class="d-inline-block align-text-top rounded"/>
                        <span className='text-white ms-2'>Chuva</span> <span className='text-primary'>Academy</span>
                    </a>
                </div>
            </nav>
        </>
    );
}

export default IndexContent;