import React , { useContext } from 'react';
import { GlobalAppContext } from './../../context';
import logoChuva from '../../images/logoChuva.png';
import 'bootstrap/dist/css/bootstrap.min.css';

function IndexContent() {

const { toggled , setToggled} = useContext(
    GlobalAppContext
);

    return (
        <>
            <nav class="navbar navbar-dark bg-dark">
                <div class="container-fluid">
                    <button id='MenuButton' type='button' href="#/" className="navbar-toggler me-1" onClick={() =>setToggled(!toggled)}>
                        <span className='navbar-toggler-icon navbar-toggler-icon-white'/>
                    </button>
                    <a class="navbar-brand chuva" href="/home">
                        <img src={logoChuva} alt="Logo" width="25" height="24" class="d-inline-block align-text-top rounded"/>
                        <span className='text-white ms-2'>Chuva</span> <span className='text-primary'>Academy</span>
                    </a>
                </div>
            </nav>
            <div>
                <h1>Hello Maky kk</h1>
            </div>
        </>
    );
}

export default IndexContent;